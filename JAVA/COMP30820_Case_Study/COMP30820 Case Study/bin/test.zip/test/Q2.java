package test;

public class Q2 {
	public static void main(String[] args) {
		// test cases

		// should return: "" (i.e. a string with no characters)
		System.out.println("test case 1: " + getLCS("hello", "HELLO"));
	
		// should return: "ing"
		System.out.println("test case 2: " + getLCS("computing", "working"));
	}

	// write this method
	public static String getLCS(String s1, String s2) {
		return "";
	}
}
