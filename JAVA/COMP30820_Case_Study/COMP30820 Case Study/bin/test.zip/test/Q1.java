package test;

public class Q1 {
	public static void main(String[] args) {
		// test cases
		
		// should return: 0
		System.out.println("test case 1: " + getSumDigits(""));

		// should return: 0
		System.out.println("test case 2: " + getSumDigits("hello"));
		
		// should return: 5
		System.out.println("test case 3: " + getSumDigits("a2b3"));
	}

	// write this method
	public static int getSumDigits(String str) {
		return 0;
	}
}
