package practical8_solutions;

public interface Rotatable {
	public abstract void rotate();
}
