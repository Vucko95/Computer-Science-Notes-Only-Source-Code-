package practical8_solutions;

public interface Scalable {
	public abstract void scale(double factor);
}
