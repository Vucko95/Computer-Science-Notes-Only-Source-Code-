package practical9_solutions;

public interface Scalable {
	public abstract void scale(double factor);
}
