package practical9_solutions;

public interface Rotatable {
	public abstract void rotate();
}
