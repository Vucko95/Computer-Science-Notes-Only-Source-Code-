package practical9_code;

public interface Rotatable {
	public abstract void rotate();
}
