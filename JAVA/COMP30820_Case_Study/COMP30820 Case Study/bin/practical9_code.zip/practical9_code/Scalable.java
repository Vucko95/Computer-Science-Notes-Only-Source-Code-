package practical9_code;

public interface Scalable {
	public abstract void scale(double factor);
}
