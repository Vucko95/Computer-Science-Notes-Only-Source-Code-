#!/bin/bash     
java -cp ../webapps/juddiv3/WEB-INF/lib:../webapps/juddiv3/WEB-INF/lib/* org.apache.juddi.v3.auth.MD5XMLDocAuthenticator